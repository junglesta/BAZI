#!/bin/bash
echo "🔧 Setting up Ba Zi Picker..."
npm install -g pnpm@9.12.2
pnpm install
echo "✅ Setup complete! Run 'pnpm start' to begin."
