// generate_bazi_dataset.mjs
// Simplified version - easier to understand
// Run with: node generate_bazi_dataset.mjs

import { writeFileSync } from "node:fs";
import { Solar } from "lunar-javascript";

// Configuration
const START_YEAR = 1920;
const END_DATE = new Date(); // Today

console.log("Starting Ba Zi dataset generation...");

// Helper function to format date as YYYY-MM-DD
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

// Generate dates from start to end
function* generateDates(startYear, endDate) {
  const start = new Date(startYear, 0, 1); // January 1st of start year
  const end = new Date(endDate);

  // Set to start of day for end date
  end.setHours(0, 0, 0, 0);

  let current = new Date(start);
  while (current <= end) {
    yield new Date(current);
    current.setDate(current.getDate() + 1);
  }
}

// Main generation logic
function generateBaZiData() {
  const baziData = {};
  let count = 0;

  for (const date of generateDates(START_YEAR, END_DATE)) {
    try {
      // Create Solar date from JavaScript Date
      // Note: Solar.fromDate uses the date as-is (treats it as Beijing time)
      const solar = Solar.fromDate(date);
      const lunar = solar.getLunar();
      const eightChar = lunar.getEightChar();

      // Get the date key in YYYY-MM-DD format
      const dateKey = formatDate(date);

      // Store the Ba Zi pillars
      baziData[dateKey] = {
        year: eightChar.getYear(), // Year pillar (年柱)
        month: eightChar.getMonth(), // Month pillar (月柱)
        day: eightChar.getDay(), // Day pillar (日柱)
        // Hour pillar not included as it varies by hour of day

        // Optional: Add more details
        yearGan: eightChar.getYearGan(), // Year heavenly stem
        yearZhi: eightChar.getYearZhi(), // Year earthly branch
        monthGan: eightChar.getMonthGan(), // Month heavenly stem
        monthZhi: eightChar.getMonthZhi(), // Month earthly branch
        dayGan: eightChar.getDayGan(), // Day heavenly stem
        dayZhi: eightChar.getDayZhi(), // Day earthly branch
        shengxiao: lunar.getYearShengXiao(), // Zodiac animal
        lunarMonth: lunar.getMonthInChinese(),
        lunarDay: lunar.getDayInChinese(),
      };

      count++;

      // Progress indicator every 1000 days
      if (count % 1000 === 0) {
        console.log(`Processed ${count} days... (currently at ${dateKey})`);
      }
    } catch (error) {
      console.error(
        `Error processing date ${formatDate(date)}:`,
        error.message,
      );
    }
  }

  return baziData;
}

// Generate and save the dataset
console.log(`Generating Ba Zi data from ${START_YEAR} to today...`);
const data = generateBaZiData();

// Save to JSON file
const filename = `bazi_${START_YEAR}_today.json`;
writeFileSync(filename, JSON.stringify(data, null, 2));

console.log(
  `✅ Success! Generated ${Object.keys(data).length} days of Ba Zi data`,
);
console.log(`📁 Saved to: ${filename}`);

// Show a sample of the data
const sampleDates = Object.keys(data).slice(0, 3);
console.log("\nSample data:");
sampleDates.forEach((date) => {
  console.log(
    `${date}: ${data[date].year} ${data[date].month} ${data[date].day}`,
  );
});
