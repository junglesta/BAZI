// scripts/generate_range.mjs
// Generate Ba Zi dataset for a specific date range
// Usage: node scripts/generate_range.mjs --from 2020-01-01 --to 2025-12-31

import { writeFileSync } from "node:fs";
import { Solar } from "lunar-javascript";

function parseArgs() {
  const args = process.argv.slice(2);
  const params = {};

  for (let i = 0; i < args.length; i += 2) {
    const key = args[i].replace("--", "");
    const value = args[i + 1];
    params[key] = value;
  }

  return {
    from: params.from || "2020-01-01",
    to: params.to || new Date().toISOString().split("T")[0],
    output: params.output || "bazi_range.json",
  };
}

function generateRange(fromDate, toDate) {
  const data = {};
  const start = new Date(fromDate);
  const end = new Date(toDate);

  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const solar = Solar.fromDate(d);
    const lunar = solar.getLunar();
    const ec = lunar.getEightChar();

    const key = d.toISOString().split("T")[0];
    data[key] = {
      year: ec.getYear(),
      month: ec.getMonth(),
      day: ec.getDay(),
      shengxiao: lunar.getYearShengXiao(),
    };
  }

  return data;
}

const { from, to, output } = parseArgs();
console.log(`Generating Ba Zi data from ${from} to ${to}...`);

const data = generateRange(from, to);
writeFileSync(output, JSON.stringify(data, null, 2));

console.log(`✅ Generated ${Object.keys(data).length} days → ${output}`);

// ============================================

// scripts/validate_dataset.mjs
// Validate the integrity of generated Ba Zi dataset
// Usage: node scripts/validate_dataset.mjs

import { readFileSync, existsSync } from "node:fs";
import { Solar } from "lunar-javascript";

function validateDataset(filename = "bazi_1920_today.json") {
  if (!existsSync(filename)) {
    console.error(`❌ File not found: ${filename}`);
    console.log('Run "pnpm generate" first to create the dataset.');
    process.exit(1);
  }

  console.log(`🔍 Validating ${filename}...`);

  const data = JSON.parse(readFileSync(filename, "utf8"));
  const dates = Object.keys(data).sort();

  const stats = {
    totalDays: dates.length,
    firstDate: dates[0],
    lastDate: dates[dates.length - 1],
    missingDays: [],
    invalidEntries: [],
    uniqueYearPillars: new Set(),
    uniqueMonthPillars: new Set(),
    uniqueDayPillars: new Set(),
  };

  // Check for missing days
  const startDate = new Date(dates[0]);
  const endDate = new Date(dates[dates.length - 1]);

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const key = d.toISOString().split("T")[0];

    if (!data[key]) {
      stats.missingDays.push(key);
    } else {
      // Validate entry structure
      const entry = data[key];

      if (!entry.year || !entry.month || !entry.day) {
        stats.invalidEntries.push(key);
      } else {
        stats.uniqueYearPillars.add(entry.year);
        stats.uniqueMonthPillars.add(entry.month);
        stats.uniqueDayPillars.add(entry.day);

        // Verify against lunar-javascript
        if (Math.random() < 0.01) {
          // Spot check 1% of entries
          const [y, m, d] = key.split("-").map(Number);
          const solar = Solar.fromYmd(y, m, d);
          const ec = solar.getLunar().getEightChar();

          if (
            entry.year !== ec.getYear() ||
            entry.month !== ec.getMonth() ||
            entry.day !== ec.getDay()
          ) {
            console.warn(`⚠️ Mismatch at ${key}:`);
            console.warn(
              `  Dataset: ${entry.year} ${entry.month} ${entry.day}`,
            );
            console.warn(
              `  Computed: ${ec.getYear()} ${ec.getMonth()} ${ec.getDay()}`,
            );
          }
        }
      }
    }
  }

  // Print validation report
  console.log("\n📊 Validation Report");
  console.log("=".repeat(40));
  console.log(`Total Days: ${stats.totalDays}`);
  console.log(`Date Range: ${stats.firstDate} to ${stats.lastDate}`);
  console.log(`Missing Days: ${stats.missingDays.length}`);
  console.log(`Invalid Entries: ${stats.invalidEntries.length}`);
  console.log(`Unique Year Pillars: ${stats.uniqueYearPillars.size}/60`);
  console.log(`Unique Month Pillars: ${stats.uniqueMonthPillars.size}/60`);
  console.log(`Unique Day Pillars: ${stats.uniqueDayPillars.size}/60`);

  if (stats.missingDays.length > 0) {
    console.log(
      "\n⚠️ Missing days:",
      stats.missingDays.slice(0, 10).join(", "),
    );
  }

  if (stats.invalidEntries.length > 0) {
    console.log(
      "\n❌ Invalid entries:",
      stats.invalidEntries.slice(0, 10).join(", "),
    );
  }

  const isValid =
    stats.missingDays.length === 0 && stats.invalidEntries.length === 0;

  if (isValid) {
    console.log("\n✅ Dataset is valid!");
  } else {
    console.log(
      '\n❌ Dataset has issues. Please regenerate with "pnpm generate"',
    );
    process.exit(1);
  }

  return isValid;
}

// Run validation
const filename = process.argv[2] || "bazi_1920_today.json";
validateDataset(filename);

// ============================================

// scripts/benchmark.mjs
// Benchmark Ba Zi calculation performance
// Usage: node scripts/benchmark.mjs

import { Solar } from "lunar-javascript";
import { performance } from "node:perf_hooks";

function benchmark() {
  console.log("🚀 Ba Zi Calculation Benchmark\n");

  const testCases = [
    { name: "Single date", iterations: 1000 },
    { name: "One month", iterations: 30 },
    { name: "One year", iterations: 1 },
  ];

  for (const test of testCases) {
    const dates = [];
    const baseDate = new Date(2024, 0, 1);

    // Prepare dates
    const totalDates =
      test.name === "Single date" ? 1 : test.name === "One month" ? 30 : 365;

    for (let i = 0; i < totalDates; i++) {
      const d = new Date(baseDate);
      d.setDate(d.getDate() + i);
      dates.push(d);
    }

    // Benchmark
    const start = performance.now();

    for (let i = 0; i < test.iterations; i++) {
      for (const date of dates) {
        const solar = Solar.fromDate(date);
        const ec = solar.getLunar().getEightChar();
        const pillars = {
          year: ec.getYear(),
          month: ec.getMonth(),
          day: ec.getDay(),
          hour: ec.getTime(),
        };
      }
    }

    const end = performance.now();
    const duration = end - start;
    const totalCalcs = test.iterations * totalDates;
    const perCalc = duration / totalCalcs;

    console.log(`📊 ${test.name}:`);
    console.log(`   Total calculations: ${totalCalcs}`);
    console.log(`   Total time: ${duration.toFixed(2)}ms`);
    console.log(`   Per calculation: ${perCalc.toFixed(4)}ms`);
    console.log(`   Calculations/sec: ${(1000 / perCalc).toFixed(0)}\n`);
  }
}

benchmark();

// ============================================

// scripts/export_csv.mjs
// Export Ba Zi dataset to CSV format
// Usage: node scripts/export_csv.mjs

import { readFileSync, writeFileSync, existsSync } from "node:fs";

function exportToCSV(
  jsonFile = "bazi_1920_today.json",
  csvFile = "bazi_export.csv",
) {
  if (!existsSync(jsonFile)) {
    console.error(`❌ File not found: ${jsonFile}`);
    process.exit(1);
  }

  console.log(`📄 Exporting ${jsonFile} to CSV...`);

  const data = JSON.parse(readFileSync(jsonFile, "utf8"));
  const rows = ["Date,Year Pillar,Month Pillar,Day Pillar,Zodiac"];

  for (const [date, info] of Object.entries(data)) {
    const row = [
      date,
      info.year || "",
      info.month || "",
      info.day || "",
      info.shengxiao || "",
    ].join(",");
    rows.push(row);
  }

  writeFileSync(csvFile, rows.join("\n"));
  console.log(`✅ Exported ${Object.keys(data).length} rows → ${csvFile}`);
}

const jsonFile = process.argv[2];
const csvFile = process.argv[3];
exportToCSV(jsonFile, csvFile);

// ============================================

// scripts/server_enhanced.mjs
// Enhanced server with more features
// Usage: node scripts/server_enhanced.mjs

import express from "express";
import compression from "compression";
import cors from "cors";
import helmet from "helmet";
import { readFileSync, existsSync } from "node:fs";
import { Solar } from "lunar-javascript";

const app = express();

// Middleware
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: [
          "'self'",
          "'unsafe-inline'",
          "https://cdn.tailwindcss.com",
          "https://unpkg.com",
          "https://cdnjs.cloudflare.com",
        ],
        styleSrc: ["'self'", "'unsafe-inline'"],
      },
    },
  }),
);
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.static("."));

// Load dataset if available
const DATASET_PATH = "./bazi_1920_today.json";
const dataset = existsSync(DATASET_PATH)
  ? JSON.parse(readFileSync(DATASET_PATH, "utf8"))
  : null;

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    version: "1.0.0",
    dataset: dataset ? "loaded" : "not found",
    datasetSize: dataset ? Object.keys(dataset).length : 0,
  });
});

// API: Get Ba Zi for specific date/time
app.get("/api/bazi", (req, res) => {
  try {
    const { date, hour = "0", tz = "UTC" } = req.query;

    if (!date) {
      return res.status(400).json({ error: "Missing date parameter" });
    }

    const [year, month, day] = date.split("-").map(Number);
    const h = parseInt(hour);

    // Calculate Ba Zi
    const solar = Solar.fromYmdHms(year, month, day, h, 0, 0);
    const lunar = solar.getLunar();
    const ec = lunar.getEightChar();

    const result = {
      input: { date, hour: h, timezone: tz },
      pillars: {
        year: ec.getYear(),
        month: ec.getMonth(),
        day: ec.getDay(),
        hour: ec.getTime(),
      },
      elements: {
        yearStem: ec.getYearGan(),
        yearBranch: ec.getYearZhi(),
        monthStem: ec.getMonthGan(),
        monthBranch: ec.getMonthZhi(),
        dayStem: ec.getDayGan(),
        dayBranch: ec.getDayZhi(),
        hourStem: ec.getTimeGan(),
        hourBranch: ec.getTimeZhi(),
      },
      lunar: {
        date: lunar.toString(),
        month: lunar.getMonthInChinese(),
        day: lunar.getDayInChinese(),
        shengxiao: lunar.getYearShengXiao(),
      },
    };

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API: Batch calculation
app.post("/api/bazi/batch", (req, res) => {
  try {
    const { dates } = req.body;

    if (!Array.isArray(dates)) {
      return res.status(400).json({ error: "dates must be an array" });
    }

    const results = dates.map(({ date, hour = 0 }) => {
      const [year, month, day] = date.split("-").map(Number);
      const solar = Solar.fromYmdHms(year, month, day, hour, 0, 0);
      const ec = solar.getLunar().getEightChar();

      return {
        date,
        hour,
        pillars: {
          year: ec.getYear(),
          month: ec.getMonth(),
          day: ec.getDay(),
          hour: ec.getTime(),
        },
      };
    });

    res.json({ results });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`🌟 Enhanced Ba Zi Server`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log(`📊 Dataset: ${dataset ? "Loaded" : "Not found"}`);
  console.log(`🔧 Health check: http://localhost:${PORT}/health`);
});
