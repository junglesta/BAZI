# 🎯 Ba Zi Picker - Quick Start Guide

Get your Four Pillars of Destiny (八字) calculated in seconds! This guide will have you up and running in under 2 minutes.

## 📖 What is Ba Zi?

**Ba Zi** (八字, "Eight Characters") is a Chinese astrological system that maps your birth date/time to four pillars:
- **Year Pillar** (年柱) - Your social/external self
- **Month Pillar** (月柱) - Your career and parents
- **Day Pillar** (日柱) - Your true self and marriage
- **Hour Pillar** (時柱) - Your children and later life

Each pillar consists of a Heavenly Stem + Earthly Branch (like 甲子, 乙丑, etc.)

## 🚀 Fastest Start (30 seconds)

### Option 1: Just Open and Use!
1. Save the `index.html` file from the fixed version
2. Double-click to open in your browser
3. Enter your birth date/time
4. Click "Get Ba Zi"
5. Done! Your Four Pillars appear instantly

**That's it!** No installation, no server, no dependencies needed.

## 💻 Installation Options

### Client-Only (Recommended for Personal Use)
```bash
# No installation needed!
# Just download index.html and open it
```

**Features:**
- ✅ Works offline
- ✅ No server required  
- ✅ Instant calculations
- ✅ Privacy (all calculations local)

### With Node.js Tools (For Developers)

#### Prerequisites
```bash
# Check if you have Node.js
node --version  # Should be v14+

# If not, install from nodejs.org
```

#### Generate Historical Dataset
```bash
# Install the lunar calculation library
npm install lunar-javascript

# Generate dataset from 1920 to today
node generate_bazi_dataset.mjs

# Output: bazi_1920_today.json (~38MB)
```

#### Run with Server (Optional)
```bash
# Install dependencies
npm install express lunar-javascript

# Start server
node server.mjs

# Open browser to http://localhost:8080
```

## 🎮 How to Use

### Basic Usage

1. **Enter Birth Information:**
   - **Year**: 1985 (example)
   - **Month**: 6 (June)
   - **Day**: 15
   - **Hour**: 14 (2:00 PM in 24-hour format)
   - **Timezone**: Select your birth location timezone

2. **Click "Get Ba Zi"** or **"Use Now"** for current time

3. **Read Your Results:**
   ```
   Year:  乙丑 (Wood Ox)
   Month: 壬午 (Water Horse)  
   Day:   癸亥 (Water Pig)
   Hour:  己未 (Earth Goat)
   ```

### Understanding Time Zones

⚠️ **Important**: Ba Zi uses Beijing solar time. The app automatically converts your local time.

Example:
- Born: June 15, 1985 at 2:00 PM in New York
- Converts to: June 16, 1985 at 2:00 AM Beijing time
- Your Day Pillar might be different than expected!

## 📊 Output Formats

### Visual Cards (Default)
- Four colored cards showing each pillar
- Chinese characters + pinyin
- Heavenly Stem and Earthly Branch details

### JSON Data
```json
{
  "pillars": {
    "year": "乙丑",
    "month": "壬午",
    "day": "癸亥",
    "hour": "己未"
  },
  "shengxiao": "牛",  // Zodiac animal
  "elements": {
    "yearStem": "乙",   // Wood
    "yearBranch": "丑",  // Ox
    // ... etc
  }
}
```

## 🛠️ Common Use Cases

### Personal Ba Zi Reading
```javascript
// Just enter your birth info
Year: 1990, Month: 8, Day: 25, Hour: 15
Timezone: Your birth location
→ Get your Four Pillars instantly
```

### Batch Processing (with Node.js)
```javascript
// Use the generated dataset
const data = require('./bazi_1920_today.json');
const myBirthday = data['1990-08-25'];
console.log(myBirthday); // { year: "庚午", month: "甲申", day: "戊寅" }
```

### API Integration (with Server)
```bash
# GET request
curl "http://localhost:8080/api/bazi?date=1990-08-25&hour=15&tz=Asia/Shanghai"

# Returns HTML fragment for HTMX
```

## 🔧 Troubleshooting

### Issue: "Invalid Date" Error
**Solution**: Check day is valid for the month (e.g., no Feb 30)

### Issue: Wrong Pillars Showing
**Solution**: 
1. Verify timezone is correct for birth location
2. Remember Ba Zi uses solar calendar, not lunar
3. Hour pillar changes every 2 hours (Chinese double-hours)

### Issue: Server Won't Start
```bash
# Check port isn't in use
lsof -i :8080  # Mac/Linux
netstat -ano | findstr :8080  # Windows

# Use different port
PORT=3000 node server.mjs
```

## 📚 Quick Reference

### Chinese Hour System
| 24hr Time | Chinese Hour | Branch | Animal |
|-----------|--------------|--------|--------|
| 23:00-00:59 | 子時 | 子 | Rat |
| 01:00-02:59 | 丑時 | 丑 | Ox |
| 03:00-04:59 | 寅時 | 寅 | Tiger |
| 05:00-06:59 | 卯時 | 卯 | Rabbit |
| 07:00-08:59 | 辰時 | 辰 | Dragon |
| 09:00-10:59 | 巳時 | 巳 | Snake |
| 11:00-12:59 | 午時 | 午 | Horse |
| 13:00-14:59 | 未時 | 未 | Goat |
| 15:00-16:59 | 申時 | 申 | Monkey |
| 17:00-18:59 | 酉時 | 酉 | Rooster |
| 19:00-20:59 | 戌時 | 戌 | Dog |
| 21:00-22:59 | 亥時 | 亥 | Pig |

### File Structure
```
bazi-picker/
├── index.html                 # Main app (all you need!)
├── generate_bazi_dataset.mjs  # Dataset generator (optional)
├── server.mjs                 # Express server (optional)
├── bazi_1920_today.json      # Generated dataset (optional)
└── README.md                  # This file
```

## 🎯 Next Steps

1. **Calculate your Ba Zi** - Start with your own birth date
2. **Learn the meanings** - Research your pillars' elements
3. **Explore combinations** - See how pillars interact
4. **Generate datasets** - Create lookups for your app
5. **Build features** - Add interpretations, compatibility checks, etc.

## 💡 Pro Tips

- 🌍 **Always use birth location timezone** - Not current location
- 🕐 **Birth time matters** - Hour pillar changes every 2 hours
- 📅 **Solar vs Lunar** - Ba Zi uses solar calendar, not Chinese lunar
- 🧮 **Manual calculation** - The app handles complex solar term boundaries
- 📊 **Dataset efficiency** - Pre-generate for faster lookups in production

## 🆘 Get Help

- **Documentation**: Check `lunar-javascript` [docs](https://github.com/6tail/lunar-javascript)
- **Ba Zi Theory**: Research "Four Pillars of Destiny" or "八字命理"
- **Timezone Issues**: Use [timeanddate.com](https://timeanddate.com) to verify historical timezones

---

**Ready to discover your Four Pillars? Open `index.html` and start exploring!** 🎊