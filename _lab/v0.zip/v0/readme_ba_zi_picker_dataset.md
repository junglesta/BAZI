# BaZi Picker & Dataset — README

A lightweight, **no‑framework** way to compute and display **Ba Zi (Four Pillars)** for any date/time. You can run it fully **client‑side** or optionally use a tiny server. It also includes a generator to create a **static JSON dataset** for fast lookups.

---

## What’s inside

- `` — A single page that shows a **4‑field calendar form** (Year, Month, Day, Hour, plus Timezone) and displays the **Year/Month/Day/Hour pillars** below on the same page. Uses **HTMX** for the submit/swap UX, but computes in the browser via `lunar-javascript`.
- `` — Node script to precompute a **daily Ba Zi dataset** (Y/M/D pillars) from a start date to today. Output is `bazi_YYYY_today.json` keyed by `YYYY-MM-DD`.
- `` *(optional)* — Minimal Express server that serves the page and exposes `/api/bazi` which returns an **HTML snippet** for HTMX. If a dataset file is present, it uses it for Y/M/D and computes the hour live.

> You can also use the alternative **“BaZi JSON Generator — 1900→2040 (no server)”** page to generate **hourly** (every 2h) JSONs entirely in the browser, one file per year, with no Node required.

---

## Quick start (client‑only)

1. Open `index.html` in your browser.
2. Fill **Year / Month / Day / Hour** and choose a **Timezone** (defaults to your local zone).
3. Click **Get Ba Zi** → the four pillars and a JSON block appear below.

No build, no backend. Works offline once the page loads.

**Key libraries (CDN):**

- [HTMX](https://htmx.org/) for simple form→target swapping (no custom JS required to replace sections of the page).
- [`lunar-javascript`](https://github.com/6tail/lunar-javascript) to compute stems/branches accurately.

---

## How it works (in `index.html`)

The page builds a Date in your chosen timezone using `Intl.DateTimeFormat`, then feeds it to `lunar-javascript` to compute the pillars.

```html
<!-- Important includes -->
<script src="https://unpkg.com/htmx.org@1.9.12"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lunar-javascript/1.7.3/lunar.min.js"></script>

<form id="bazi-form" hx-on:submit="window.handleSubmit(event)" hx-target="#result" hx-swap="innerHTML">
  <!-- Year / Month / Day / Hour + Timezone inputs -->
  <button type="submit">Get Ba Zi</button>
</form>

<script>
  function computeBaZiClient(y,m,d,h,tz){
    const pad=(n)=>String(n).padStart(2,'0');
    const isoLocal = `${pad(y)}-${pad(m)}-${pad(d)}T${pad(h)}:00:00`;
    const dtf = new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
    const parts = dtf.formatToParts(new Date(isoLocal));
    const get=(t)=>parts.find(p=>p.type===t)?.value;
    const date = new Date(`${get('year')}-${get('month')}-${get('day')}T${get('hour')}:${get('minute')}:${get('second')}Z`);

    const solar = Solar.fromDate(date);
    const ec = solar.getLunar().getEightChar();
    return { year: ec.getYear(), month: ec.getMonth(), day: ec.getDay(), hour: ec.getTime() };
  }

  window.handleSubmit = (e)=>{
    e.preventDefault();
    const f = e.target;
    const data = computeBaZiClient(+f.year.value, +f.month.value, +f.day.value, +f.hour.value, f.tz.value);
    document.querySelector('#result').innerHTML = `<pre>${JSON.stringify(data,null,2)}</pre>`;
  };
</script>
```

---

## Optional: Server mode (HTMX endpoint)

If you prefer server‑rendered snippets for the result area, run the tiny Express server and let the form do an HTMX GET to `/api/bazi`.

```bash
npm install express lunar-javascript
node server.mjs
# open http://localhost:8080
```

Example endpoint response HTML (what `/api/bazi` returns):

```html
<div class="grid md:grid-cols-4 gap-4">
  <div class="rounded-2xl bg-white border p-4"><div class="text-xs">Year</div><div class="text-2xl">乙巳</div></div>
  <div class="rounded-2xl bg-white border p-4"><div class="text-xs">Month</div><div class="text-2xl">甲申</div></div>
  <div class="rounded-2xl bg-white border p-4"><div class="text-xs">Day</div><div class="text-2xl">庚戌</div></div>
  <div class="rounded-2xl bg-white border p-4"><div class="text-xs">Hour</div><div class="text-2xl">壬子</div></div>
</div>
```

> You don’t need the server for normal use; it’s there if you want server‑side rendering or to share a dataset.

---

## Precompute a dataset (daily Y/M/D pillars)

If you want instant historical lookups without computing anything in the browser, build a static JSON once and ship it with your app.

```bash
# 1) Install the library
npm install lunar-javascript

# 2) Run the generator
node generate_bazi_dataset.mjs

# 3) You’ll get: bazi_1920_today.json
#    Shape: { "YYYY-MM-DD": { "year": "甲子", "month": "乙丑", "day": "丙寅" } }
```

**Snippet from the generator:**

```js
import { writeFileSync } from 'node:fs';
import { Solar } from 'lunar-javascript';

const start = new Date(Date.UTC(1920,0,1));
const today = new Date();
const end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
const out = {};

for(let d=new Date(start); d<=end; d.setUTCDate(d.getUTCDate()+1)){
  const ec = Solar.fromDate(d).getLunar().getEightChar();
  out[d.toISOString().slice(0,10)] = { year: ec.getYear(), month: ec.getMonth(), day: ec.getDay() };
}

writeFileSync('bazi_1920_today.json', JSON.stringify(out));
```

---

## Fully client‑side hourly dataset (no Node, no server)

Use the alternative **BaZi JSON Generator (1900→2040)** page. It will generate **every 2‑hour slot** for each date in a range and download one **JSON per year** to keep memory low. Steps:

1. Open the generator HTML page in your browser.
2. Pick start/end years and timezone.
3. Click **Generate & Download**. You’ll get files like `bazi_1900_Europe-Rome.json`, one per year.

> This is handy if you want a static, offline dataset that already includes **hour pillars** (00, 02, …, 22) for each day.

---

## Data shape(s)

### Result object (from `index.html`)

```json
{
  "iso": "2025-08-10T00:40:00.000Z",
  "pillars": {
    "year": "乙巳",
    "month": "甲申",
    "day": "庚戌",
    "hour": "壬子"
  },
  "lunar": "…",
  "lunarFull": "…",
  "shengxiao": "蛇"
}
```

### Daily dataset (`bazi_1920_today.json`)

```json
{
  "1920-01-01": { "year": "己未", "month": "戊子", "day": "乙酉" },
  "1920-01-02": { "year": "己未", "month": "戊子", "day": "丙戌" }
}
```

### Hourly per‑year file (generator page)

```json
{
  "2025-08-09": {
    "00": { "year": "乙巳", "month": "甲申", "day": "庚戌", "hour": "壬子" },
    "02": { "year": "乙巳", "month": "甲申", "day": "庚戌", "hour": "癸丑" }
  }
}
```

---

## Timezone & hour pillar notes

- The **hour pillar** depends on the **local civil time** for the location. Always compute with the correct **IANA timezone** (e.g., `Europe/Rome`).
- The calendar splits the day into 12 two‑hour branches (子, 丑, …). The code maps your selected hour to the correct branch via the constructed zoned Date.

---

## Tips & performance

- For big ranges (e.g., 1900→2040 hourly), prefer **one JSON per year** to avoid huge in‑memory blobs.
- `lunar-javascript` is fast, but precomputing datasets makes UI interactions instant and avoids re‑computing.
- You can host the JSON files on any static host (S3, GitHub Pages) and `fetch()` them on demand.

---

## FAQ

**Do I need the server?**\
No. Everything works client‑only. The server is optional if you want server‑rendered fragments or centralized datasets.

**Can I add Ten Gods / Five Elements?**\
Yes—both the page and generators can be extended to include extra fields (hidden stems, element tallies, etc.).

**Can I generate from 1900 to 2040?**\
Yes—use the client generator page (recommended) or adjust the Node script’s range.

---

## License

Use freely in your projects. If you redistribute the dataset, consider noting that it was computed with `lunar-javascript` (6tail).

====
