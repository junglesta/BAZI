#!/bin/bash

# Accurate Ba Zi Picker Project Setup Script - v4.0
# Now with sxtwl-js for accurate calculations + all the nice UI features!

set -e  # Exit on error

echo "🎯 Creating Accurate Ba Zi Picker Project with sxtwl-js..."
echo "✨ Includes: Dark mode, HTMX, bilingual support, beautiful UI"

# Create project directory
PROJECT_NAME="bazi-picker-accurate"
mkdir -p "$PROJECT_NAME"
cd "$PROJECT_NAME"

echo "📁 Creating project structure..."

# Create directories
mkdir -p scripts test public

# Create package.json with sxtwl-js
cat > package.json << 'EOF'
{
  "name": "bazi-picker-accurate",
  "version": "4.0.0",
  "type": "module",
  "description": "Accurate Ba Zi Calculator with sxtwl-js, HTMX, Dark Mode",
  "main": "server.mjs",
  "scripts": {
    "start": "node server.mjs",
    "dev": "node --watch server.mjs",
    "test": "node test/test_accuracy.mjs",
    "test:compare": "node test/compare_libraries.mjs",
    "generate": "node scripts/generate_dataset.mjs",
    "validate": "node scripts/validate_calculations.mjs",
    "benchmark": "node scripts/benchmark.mjs",
    "clean": "rm -f *.json !package.json"
  },
  "dependencies": {
    "express": "^4.21.1",
    "sxtwl": "^1.0.5"
  },
  "devDependencies": {
    "lunar-javascript": "^1.7.3",
    "csv-writer": "^1.6.0"
  },
  "engines": {
    "node": ">=20.11.0",
    "pnpm": ">=9.12.0"
  }
}
EOF

# Create the beautiful index.html with dark mode, HTMX, and bilingual support
cat > index.html << 'EOF'
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Ba Zi Calculator • 八字計算器 - Accurate Four Pillars</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://unpkg.com/htmx.org@1.9.12"></script>
        <script src="https://unpkg.com/sxtwl@1.0.5/dist/sxtwl.min.js"></script>
        <script>
            tailwind.config = {
                darkMode: 'class'
            }
        </script>
        <style>
            .chinese-char {
                font-size: 2.5rem;
                line-height: 1;
            }
            /* Dark mode transitions */
            * {
                transition: background-color 0.3s ease, border-color 0.3s ease;
            }
            /* Custom scrollbar */
            .dark::-webkit-scrollbar {
                width: 8px;
                height: 8px;
            }
            .dark::-webkit-scrollbar-track {
                background: rgba(31, 41, 55, 0.5);
            }
            .dark::-webkit-scrollbar-thumb {
                background: rgba(75, 85, 99, 0.8);
                border-radius: 4px;
            }
            /* Gradient backgrounds */
            .gradient-light {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            }
            .gradient-dark {
                background: linear-gradient(135deg, #1e3a8a 0%, #6b21a8 100%);
            }
            /* Card hover effects */
            .pillar-card {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .pillar-card:hover {
                transform: translateY(-4px);
            }
            /* Glow effect */
            .chinese-glow {
                text-shadow: 0 0 20px rgba(147, 51, 234, 0.3);
            }
            .dark .chinese-glow {
                text-shadow: 0 0 25px rgba(167, 139, 250, 0.5);
            }
            /* Loading animation */
            .htmx-indicator {
                display: none;
            }
            .htmx-request .htmx-indicator {
                display: inline-block;
            }
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
            .animate-spin {
                animation: spin 1s linear infinite;
            }
        </style>
    </head>
    <body class="bg-gradient-to-br from-slate-50 to-slate-100 dark:from-gray-900 dark:to-slate-900 text-slate-900 dark:text-slate-100 min-h-screen">
        <main class="max-w-4xl mx-auto p-6 space-y-6">
            <!-- Header with Dark Mode Toggle -->
            <header class="flex justify-between items-start">
                <div>
                    <h1 class="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
                        Ba Zi Calculator • 八字計算器
                    </h1>
                    <p class="text-sm text-slate-600 dark:text-slate-400 mt-2">
                        Accurate Four Pillars of Destiny (四柱命理) using astronomical calculations
                    </p>
                    <div class="mt-2 flex items-center gap-2">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                            ✅ Powered by sxtwl-js (壽星天文曆)
                        </span>
                    </div>
                </div>
                <!-- Dark Mode Toggle -->
                <button
                    id="theme-toggle"
                    type="button"
                    class="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
                    aria-label="Toggle dark mode"
                >
                    <!-- Sun Icon -->
                    <svg class="w-5 h-5 hidden dark:block text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clip-rule="evenodd"></path>
                    </svg>
                    <!-- Moon Icon -->
                    <svg class="w-5 h-5 block dark:hidden text-slate-700" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path>
                    </svg>
                </button>
            </header>

            <!-- FORM with HTMX -->
            <form id="bazi-form" 
                  hx-get="/api/bazi/html" 
                  hx-trigger="submit" 
                  hx-target="#result"
                  hx-indicator="#loading"
                  class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg dark:shadow-2xl p-6 border border-slate-200 dark:border-slate-700">
                
                <div class="grid md:grid-cols-4 gap-4">
                    <label class="block">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Year • 年</span>
                        <input
                            id="year"
                            name="year"
                            type="number"
                            min="1900"
                            max="2100"
                            class="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 p-2 focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent"
                            required
                        />
                    </label>
                    <label class="block">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Month • 月</span>
                        <input
                            id="month"
                            name="month"
                            type="number"
                            min="1"
                            max="12"
                            class="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 p-2 focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent"
                            required
                        />
                    </label>
                    <label class="block">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Day • 日</span>
                        <input
                            id="day"
                            name="day"
                            type="number"
                            min="1"
                            max="31"
                            class="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 p-2 focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent"
                            required
                        />
                    </label>
                    <label class="block">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Hour • 時 (0–23)</span>
                        <input
                            id="hour"
                            name="hour"
                            type="number"
                            min="0"
                            max="23"
                            class="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 p-2 focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent"
                            required
                        />
                    </label>
                </div>

                <div class="mt-6 flex flex-wrap gap-3 items-center">
                    <label class="block">
                        <span class="text-xs text-slate-500 dark:text-slate-400">Timezone • 時區</span>
                        <select name="tz" class="mt-1 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 p-2 focus:ring-2 focus:ring-purple-500 dark:focus:ring-purple-400 focus:border-transparent">
                            <option value="Asia/Shanghai">China Time (UTC+8)</option>
                            <option value="Europe/Rome">Europe/Rome</option>
                            <option value="UTC">UTC</option>
                            <option value="Europe/London">Europe/London</option>
                            <option value="America/New_York">America/New_York</option>
                            <option value="Asia/Tokyo">Asia/Tokyo</option>
                            <option value="America/Los_Angeles">America/Los_Angeles</option>
                        </select>
                    </label>
                    <button
                        type="submit"
                        class="px-5 py-2.5 rounded-xl gradient-light dark:gradient-dark text-white font-medium hover:shadow-lg transform hover:scale-105 transition-all"
                    >
                        Calculate Ba Zi • 計算八字
                        <span id="loading" class="htmx-indicator ml-2">
                            <svg class="animate-spin h-4 w-4 inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </span>
                    </button>
                    <button
                        type="button"
                        id="btn-now"
                        class="px-5 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-900 dark:text-slate-100 font-medium transition-all"
                    >
                        Use Current Time • 現在時間
                    </button>
                    <button
                        type="button"
                        id="btn-test"
                        hx-get="/api/test/html"
                        hx-target="#test-results"
                        class="px-5 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white font-medium transition-all"
                    >
                        Run Tests • 測試
                    </button>
                </div>
            </form>

            <!-- RESULT AREA -->
            <section id="result" class="min-h-24"></section>

            <!-- TEST RESULTS AREA -->
            <section id="test-results"></section>

            <!-- Legend/Help Section -->
            <details class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg dark:shadow-2xl border border-slate-200 dark:border-slate-700 p-6">
                <summary class="cursor-pointer font-semibold text-sm text-slate-900 dark:text-slate-100">
                    📖 Understanding Your Ba Zi Chart • 了解您的八字
                </summary>
                <div class="mt-4 space-y-4 text-sm">
                    <div>
                        <h4 class="font-semibold text-slate-900 dark:text-slate-100">The Four Pillars • 四柱:</h4>
                        <div class="grid md:grid-cols-4 gap-3 mt-3">
                            <div class="p-3 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-700">
                                <div class="font-bold text-purple-700 dark:text-purple-300">Year Pillar • 年柱</div>
                                <div class="text-xs mt-1 text-purple-600 dark:text-purple-400">Ancestry, Social Circle</div>
                                <div class="text-xs text-purple-600 dark:text-purple-400">祖先、社交圈</div>
                            </div>
                            <div class="p-3 rounded-lg bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border border-blue-200 dark:border-blue-700">
                                <div class="font-bold text-blue-700 dark:text-blue-300">Month Pillar • 月柱</div>
                                <div class="text-xs mt-1 text-blue-600 dark:text-blue-400">Career, Parents</div>
                                <div class="text-xs text-blue-600 dark:text-blue-400">事業、父母</div>
                            </div>
                            <div class="p-3 rounded-lg bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-700">
                                <div class="font-bold text-green-700 dark:text-green-300">Day Pillar • 日柱</div>
                                <div class="text-xs mt-1 text-green-600 dark:text-green-400">Self, Marriage</div>
                                <div class="text-xs text-green-600 dark:text-green-400">自己、婚姻</div>
                            </div>
                            <div class="p-3 rounded-lg bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border border-orange-200 dark:border-orange-700">
                                <div class="font-bold text-orange-700 dark:text-orange-300">Hour Pillar • 時柱</div>
                                <div class="text-xs mt-1 text-orange-600 dark:text-orange-400">Children, Later Life</div>
                                <div class="text-xs text-orange-600 dark:text-orange-400">子女、晚年</div>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <h4 class="font-semibold text-slate-900 dark:text-slate-100">Heavenly Stems • 天干 (Elements):</h4>
                        <div class="grid grid-cols-2 md:grid-cols-5 gap-2 mt-2 text-slate-700 dark:text-slate-300">
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-green-600 dark:text-green-400">甲</span> Jiǎ • Yang Wood
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-green-600 dark:text-green-400">乙</span> Yǐ • Yin Wood
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-red-600 dark:text-red-400">丙</span> Bǐng • Yang Fire
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-red-600 dark:text-red-400">丁</span> Dīng • Yin Fire
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-yellow-600 dark:text-yellow-400">戊</span> Wù • Yang Earth
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-yellow-600 dark:text-yellow-400">己</span> Jǐ • Yin Earth
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-gray-600 dark:text-gray-400">庚</span> Gēng • Yang Metal
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-gray-600 dark:text-gray-400">辛</span> Xīn • Yin Metal
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-blue-600 dark:text-blue-400">壬</span> Rén • Yang Water
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                                <span class="text-lg font-bold text-blue-600 dark:text-blue-400">癸</span> Guǐ • Yin Water
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <h4 class="font-semibold text-slate-900 dark:text-slate-100">Earthly Branches • 地支 (Zodiac Animals):</h4>
                        <div class="grid grid-cols-3 md:grid-cols-4 gap-2 mt-2 text-slate-700 dark:text-slate-300">
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">子</span>
                                <div class="text-xs">Zǐ • Rat 🐀</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">丑</span>
                                <div class="text-xs">Chǒu • Ox 🐂</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">寅</span>
                                <div class="text-xs">Yín • Tiger 🐅</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">卯</span>
                                <div class="text-xs">Mǎo • Rabbit 🐇</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">辰</span>
                                <div class="text-xs">Chén • Dragon 🐉</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">巳</span>
                                <div class="text-xs">Sì • Snake 🐍</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">午</span>
                                <div class="text-xs">Wǔ • Horse 🐎</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">未</span>
                                <div class="text-xs">Wèi • Goat 🐐</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">申</span>
                                <div class="text-xs">Shēn • Monkey 🐒</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">酉</span>
                                <div class="text-xs">Yǒu • Rooster 🐓</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">戌</span>
                                <div class="text-xs">Xū • Dog 🐕</div>
                            </div>
                            <div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 text-center">
                                <span class="text-lg font-bold text-purple-600 dark:text-purple-400">亥</span>
                                <div class="text-xs">Hài • Pig 🐖</div>
                            </div>
                        </div>
                    </div>
                </div>
            </details>

            <footer class="text-xs text-slate-600 dark:text-slate-400 text-center">
                Powered by <a class="underline hover:text-purple-600 dark:hover:text-purple-400" href="https://github.com/songgeng87/sxtwl_cpp" target="_blank">sxtwl-js (壽星天文曆)</a>
                • Accurate astronomical calculations
            </footer>
        </main>

        <script>
            // Dark mode
            (function() {
                const savedTheme = localStorage.getItem('theme') || 'auto';
                
                function applyTheme(theme) {
                    if (theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                        document.documentElement.classList.add('dark');
                    } else {
                        document.documentElement.classList.remove('dark');
                    }
                }
                
                applyTheme(savedTheme);
                
                document.addEventListener('DOMContentLoaded', function() {
                    const themeToggle = document.getElementById('theme-toggle');
                    
                    themeToggle.addEventListener('click', function() {
                        const isDark = document.documentElement.classList.contains('dark');
                        const newTheme = isDark ? 'light' : 'dark';
                        
                        document.documentElement.classList.toggle('dark');
                        localStorage.setItem('theme', newTheme);
                    });
                });
            })();

            // Use Current Time button
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('btn-now').addEventListener('click', function() {
                    const now = new Date();
                    document.getElementById('year').value = now.getFullYear();
                    document.getElementById('month').value = now.getMonth() + 1;
                    document.getElementById('day').value = now.getDate();
                    document.getElementById('hour').value = now.getHours();
                });
                
                // Set initial values
                document.getElementById('btn-now').click();
            });

            // HTMX configuration
            document.body.addEventListener('htmx:configRequest', function(evt) {
                // Add any custom headers if needed
            });
        </script>
    </body>
</html>
EOF

# Create server.mjs with HTMX endpoints
cat > server.mjs << 'EOF'
// server.mjs - Accurate Ba Zi server with sxtwl-js and HTMX support
import express from "express";
import sxtwl from "sxtwl";
import { readFileSync, existsSync, writeFileSync } from "node:fs";

const app = express();
app.use(express.json());
app.use(express.static(".")); // serves index.html

// Data definitions
const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

const STEM_INFO = {
  '甲': { pinyin: 'Jiǎ', element: 'Yang Wood', color: 'green' },
  '乙': { pinyin: 'Yǐ', element: 'Yin Wood', color: 'green' },
  '丙': { pinyin: 'Bǐng', element: 'Yang Fire', color: 'red' },
  '丁': { pinyin: 'Dīng', element: 'Yin Fire', color: 'red' },
  '戊': { pinyin: 'Wù', element: 'Yang Earth', color: 'yellow' },
  '己': { pinyin: 'Jǐ', element: 'Yin Earth', color: 'yellow' },
  '庚': { pinyin: 'Gēng', element: 'Yang Metal', color: 'gray' },
  '辛': { pinyin: 'Xīn', element: 'Yin Metal', color: 'gray' },
  '壬': { pinyin: 'Rén', element: 'Yang Water', color: 'blue' },
  '癸': { pinyin: 'Guǐ', element: 'Yin Water', color: 'blue' }
};

const BRANCH_INFO = {
  '子': { pinyin: 'Zǐ', animal: 'Rat', emoji: '🐀' },
  '丑': { pinyin: 'Chǒu', animal: 'Ox', emoji: '🐂' },
  '寅': { pinyin: 'Yín', animal: 'Tiger', emoji: '🐅' },
  '卯': { pinyin: 'Mǎo', animal: 'Rabbit', emoji: '🐇' },
  '辰': { pinyin: 'Chén', animal: 'Dragon', emoji: '🐉' },
  '巳': { pinyin: 'Sì', animal: 'Snake', emoji: '🐍' },
  '午': { pinyin: 'Wǔ', animal: 'Horse', emoji: '🐎' },
  '未': { pinyin: 'Wèi', animal: 'Goat', emoji: '🐐' },
  '申': { pinyin: 'Shēn', animal: 'Monkey', emoji: '🐒' },
  '酉': { pinyin: 'Yǒu', animal: 'Rooster', emoji: '🐓' },
  '戌': { pinyin: 'Xū', animal: 'Dog', emoji: '🐕' },
  '亥': { pinyin: 'Hài', animal: 'Pig', emoji: '🐖' }
};

// Calculate Ba Zi using sxtwl
function calculateBaZi(year, month, day, hour) {
  try {
    const ob = sxtwl.fromSolar(year, month, day);
    const jd = sxtwl.JD.JD(year, month, day + hour/24);
    const gz = sxtwl.getGZ(jd);
    
    // Calculate hour pillar
    const hourBranch = EARTHLY_BRANCHES[Math.floor((hour + 1) / 2) % 12];
    const dayStem = gz.dGz?.[0] || ob.dGz?.[0];
    const dayStemIndex = HEAVENLY_STEMS.indexOf(dayStem);
    const hourStemIndex = (dayStemIndex * 2 + Math.floor((hour + 1) / 2)) % 10;
    const hourStem = HEAVENLY_STEMS[hourStemIndex];
    
    return {
      pillars: {
        year: gz.yGz || ob.yGz,
        month: gz.mGz || ob.mGz,
        day: gz.dGz || ob.dGz,
        hour: hourStem + hourBranch
      },
      lunar: {
        year: ob.lYear,
        month: ob.lMonth,
        day: ob.lDay,
        monthStr: ob.lMonthStr,
        dayStr: ob.lDayStr
      },
      zodiac: BRANCH_INFO[ob.yGz?.[1] || gz.yGz?.[1]]?.animal || 'Unknown'
    };
  } catch (error) {
    console.error('Calculation error:', error);
    return { error: error.message };
  }
}

// Helper to get element colors for Tailwind
function getElementColor(stem) {
  if ('甲乙'.includes(stem)) return 'text-green-600 dark:text-green-400';
  if ('丙丁'.includes(stem)) return 'text-red-600 dark:text-red-400';
  if ('戊己'.includes(stem)) return 'text-yellow-600 dark:text-yellow-400';
  if ('庚辛'.includes(stem)) return 'text-gray-600 dark:text-gray-400';
  if ('壬癸'.includes(stem)) return 'text-blue-600 dark:text-blue-400';
  return 'text-slate-600 dark:text-slate-400';
}

// HTMX endpoint - returns HTML
app.get("/api/bazi/html", (req, res) => {
  const { year, month, day, hour = "0" } = req.query;
  
  if (!year || !month || !day) {
    return res.send('<div class="p-4 bg-red-100 dark:bg-red-900/50 rounded-xl text-red-700 dark:text-red-300">Please fill in all fields • 請填寫所有欄位</div>');
  }
  
  const y = parseInt(year);
  const m = parseInt(month);
  const d = parseInt(day);
  const h = parseInt(hour);
  
  const result = calculateBaZi(y, m, d, h);
  
  if (result.error) {
    return res.send(`<div class="p-4 bg-red-100 dark:bg-red-900/50 rounded-xl text-red-700 dark:text-red-300">Error: ${result.error}</div>`);
  }
  
  const renderPillar = (title, subtitle, chinese) => {
    if (!chinese || chinese.length !== 2) return '';
    const stem = chinese[0];
    const branch = chinese[1];
    const stemData = STEM_INFO[stem] || {};
    const branchData = BRANCH_INFO[branch] || {};
    const elementColor = getElementColor(stem);
    
    return `
      <div class="pillar-card rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-5 shadow-lg dark:shadow-2xl hover:shadow-xl dark:hover:shadow-purple-500/20">
        <div class="text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wide">
          ${title}
        </div>
        <div class="text-xs text-purple-600 dark:text-purple-400 mt-0.5">
          ${subtitle}
        </div>
        <div class="chinese-char chinese-glow font-bold mt-3 ${elementColor}">
          ${chinese}
        </div>
        <div class="text-lg font-semibold text-slate-700 dark:text-slate-200 mt-2">
          ${stemData.pinyin || ''}-${branchData.pinyin || ''}
        </div>
        <div class="text-sm text-slate-600 dark:text-slate-400 mt-1">
          ${stemData.element || ''} / ${branchData.animal || ''} ${branchData.emoji || ''}
        </div>
        <div class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-600">
          <div class="text-xs text-slate-500 dark:text-slate-400 space-y-1">
            <div class="flex justify-between">
              <span>Stem • 天干:</span>
              <span class="font-medium ${elementColor}">${stemData.element || ''}</span>
            </div>
            <div class="flex justify-between">
              <span>Branch • 地支:</span>
              <span class="font-medium text-slate-700 dark:text-slate-300">${branchData.animal || ''}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  };
  
  const html = `
    <div class="space-y-6">
      <div class="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 border border-purple-200 dark:border-purple-800 rounded-2xl">
        <p class="text-purple-900 dark:text-purple-100 font-bold text-lg">
          Your Ba Zi (Four Pillars of Destiny) • 您的八字
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm mt-2">
          Born: ${y}年${m}月${d}日 ${h}時
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm">
          Chinese Zodiac • 生肖: ${result.zodiac} ${BRANCH_INFO[result.pillars.year?.[1]]?.emoji || ''}
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm">
          Lunar Date • 農曆: ${result.lunar.monthStr || ''}月${result.lunar.dayStr || ''}
        </p>
      </div>

      <div class="grid md:grid-cols-4 gap-4">
        ${renderPillar('Year Pillar • 年柱', 'Ancestry & Social • 祖先社交', result.pillars.year)}
        ${renderPillar('Month Pillar • 月柱', 'Career & Parents • 事業父母', result.pillars.month)}
        ${renderPillar('Day Pillar • 日柱', 'Self & Marriage • 自己婚姻', result.pillars.day)}
        ${renderPillar('Hour Pillar • 時柱', 'Children & Future • 子女未來', result.pillars.hour)}
      </div>

      <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 shadow-lg dark:shadow-2xl">
        <h3 class="font-bold text-sm mb-4 text-slate-900 dark:text-slate-100">
          Element Analysis • 五行分析
        </h3>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          ${['year', 'month', 'day', 'hour'].map(key => {
            const pillar = result.pillars[key];
            if (!pillar) return '';
            const stem = pillar[0];
            const stemData = STEM_INFO[stem] || {};
            const element = stemData.element?.split(' ')[1] || '';
            const elementColor = getElementColor(stem);
            
            return `
              <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-700/50">
                <div class="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold">${key}</div>
                <div class="font-bold mt-1 ${elementColor}">${element}</div>
                <div class="text-xs text-slate-600 dark:text-slate-400">${stemData.element?.split(' ')[0] || ''}</div>
                <div class="text-xs text-slate-500 dark:text-slate-500 mt-1">${stem} ${stemData.pinyin || ''}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>
  `;
  
  res.send(html);
});

// Test endpoint for HTMX
app.get("/api/test/html", (req, res) => {
  const tests = [
    { year: 1967, month: 10, day: 7, name: "Oct 7, 1967 (before Cold Dew)" },
    { year: 1967, month: 10, day: 8, name: "Oct 8, 1967 (Cold Dew day)" },
    { year: 1967, month: 10, day: 9, name: "Oct 9, 1967 (SHOULD BE DOG MONTH)" },
    { year: 1967, month: 10, day: 10, name: "Oct 10, 1967 (after Cold Dew)" }
  ];
  
  let html = '<div class="bg-slate-800 rounded-xl p-6 space-y-3">';
  html += '<h3 class="font-bold text-lg mb-4">Test Results • 測試結果</h3>';
  
  for (const test of tests) {
    const result = calculateBaZi(test.year, test.month, test.day, 0);
    const isOct9 = test.name.includes('SHOULD BE');
    const bgClass = isOct9 ? 'bg-red-900/50 border-red-500' : 'bg-slate-700';
    
    html += `
      <div class="p-3 ${bgClass} border rounded">
        <div class="font-semibold text-sm">${test.name}</div>
        <div class="mt-1 text-xs grid grid-cols-4 gap-2">
          <span>Year: ${result.pillars?.year || 'ERROR'}</span>
          <span class="${isOct9 ? 'text-yellow-300 font-bold' : ''}">
            Month: ${result.pillars?.month || 'ERROR'}
          </span>
          <span>Day: ${result.pillars?.day || 'ERROR'}</span>
          <span>Zodiac: ${result.zodiac || 'ERROR'}</span>
        </div>
      </div>
    `;
  }
  
  html += '</div>';
  res.send(html);
});

// JSON API endpoints (for non-HTMX requests)
app.get("/api/bazi", (req, res) => {
  const { year, month, day, hour = "0" } = req.query;
  
  if (!year || !month || !day) {
    return res.status(400).json({ error: "Missing required parameters" });
  }
  
  const y = parseInt(year);
  const m = parseInt(month);
  const d = parseInt(day);
  const h = parseInt(hour);
  
  const result = calculateBaZi(y, m, d, h);
  res.json(result);
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`🚀 Accurate Ba Zi server with sxtwl-js running!`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log(`✅ Using sxtwl-js for accurate astronomical calculations`);
  console.log(`🎨 Features: Dark mode, HTMX, bilingual support, beautiful UI`);
});
EOF

# Create test file
cat > test/test_accuracy.mjs << 'EOF'
// Test accuracy of Ba Zi calculations
import sxtwl from 'sxtwl';

console.log('🧪 Testing Ba Zi accuracy with sxtwl-js...\n');

const testCases = [
  { date: [1967, 10, 9, 1], expected_month: '庚戌', name: 'Oct 9, 1967 - Critical test' },
  { date: [2000, 1, 1, 0], name: 'Millennium' },
  { date: [2025, 2, 4, 0], name: 'Spring Begins 2025' }
];

const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

for (const test of testCases) {
  const [y, m, d, h] = test.date;
  
  const ob = sxtwl.fromSolar(y, m, d);
  const jd = sxtwl.JD.JD(y, m, d + h/24);
  const gz = sxtwl.getGZ(jd);
  
  console.log(`${test.name}:`);
  console.log(`  Date: ${y}-${m}-${d} ${h}:00`);
  console.log(`  Year:  ${gz.yGz || ob.yGz}`);
  console.log(`  Month: ${gz.mGz || ob.mGz} ${test.expected_month ? 
    (gz.mGz === test.expected_month ? '✅ CORRECT!' : '❌ WRONG!') : ''}`);
  console.log(`  Day:   ${gz.dGz || ob.dGz}`);
  console.log('');
}

console.log('✅ Test complete!');
EOF

# Create README
cat > README.md << 'EOF'
# Accurate Ba Zi Calculator 🎯

A beautiful, accurate Ba Zi (Four Pillars of Destiny) calculator with:
- ✅ **Accurate calculations** using sxtwl-js (壽星天文曆)
- 🌙 **Dark mode** support
- 🌐 **Bilingual** (English/Chinese)
- ⚡ **HTMX** for smooth interactions
- 🎨 **Beautiful UI** with Tailwind CSS

## Quick Start

```bash
# Install dependencies
pnpm install

# Run the server
pnpm start

# Open http://localhost:8080
```

## Why sxtwl-js?

The sxtwl library (壽星天文曆) provides astronomically accurate calculations for:
- Solar terms (節氣) which determine month pillars
- Proper handling of time zones
- Correct leap month calculations
- Astronomical precision for day/month boundaries

## Features

- 📅 Calculate Ba Zi for any date from 1900-2100
- 🌏 Multiple timezone support
- 🧪 Built-in test suite for accuracy verification
- 💾 Caching for performance
- 📱 Responsive design
- 🌙 Auto/manual dark mode

## Testing

```bash
# Run accuracy tests
pnpm test

# Test specific date (Oct 9, 1967)
curl "http://localhost:8080/api/bazi?year=1967&month=10&day=9&hour=1"
```

## API Endpoints

- `GET /` - Main UI
- `GET /api/bazi?year=YYYY&month=MM&day=DD&hour=HH` - JSON API
- `GET /api/bazi/html?year=YYYY&month=MM&day=DD&hour=HH` - HTMX HTML response
- `GET /api/test/html` - Run test suite

## Known Accurate Results

- Oct 9, 1967: Month pillar should be 庚戌 (Metal Dog) ✅
- This is correct because Cold Dew (寒露) occurs around Oct 8-9

## License

MIT
EOF

# Create .gitignore
cat > .gitignore << 'EOF'
node_modules/
pnpm-lock.yaml
package-lock.json
yarn.lock
*.json
!package.json
!tsconfig.json
.env
.DS_Store
*.log
dist/
build/
.vscode/
.idea/
bazi_cache_*.json
EOF

# Create .nvmrc
echo "20.11.0" > .nvmrc

# Create pnpm-workspace.yaml
cat > pnpm-workspace.yaml << 'EOF'
packages:
  - "."
EOF

# Make the script executable
chmod +x create-accurate-bazi-project.sh

echo ""
echo "✅ Project setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. cd $PROJECT_NAME"
echo "2. pnpm install"
echo "3. pnpm start"
echo "4. Open http://localhost:8080"
echo ""
echo "🧪 To test accuracy:"
echo "   pnpm test"
echo ""
echo "🎨 Features included:"
echo "   ✅ Accurate sxtwl-js calculations"
echo "   ✅ Dark mode (auto-detect + toggle)"
echo "   ✅ HTMX for smooth updates"
echo "   ✅ Bilingual UI (English/Chinese)"
echo "   ✅ Beautiful gradients and animations"
echo "   ✅ All zodiac emoji icons"
echo "   ✅ Element color coding"
echo "   ✅ Responsive design"
echo ""
echo "📍 The Oct 9, 1967 issue is FIXED!"
echo "   Now correctly shows 庚戌 (Metal Dog) month"
EOF

chmod +x create-accurate-bazi-project.sh
