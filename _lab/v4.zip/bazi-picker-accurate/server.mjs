// server.mjs - Accurate Ba Zi server with sxtwl-js and HTMX support
import express from "express";
import sxtwl from "sxtwl";
import { readFileSync, existsSync, writeFileSync } from "node:fs";

const app = express();
app.use(express.json());
app.use(express.static(".")); // serves index.html

// Data definitions
const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

const STEM_INFO = {
  '甲': { pinyin: 'Jiǎ', element: 'Yang Wood', color: 'green' },
  '乙': { pinyin: 'Yǐ', element: 'Yin Wood', color: 'green' },
  '丙': { pinyin: 'Bǐng', element: 'Yang Fire', color: 'red' },
  '丁': { pinyin: 'Dīng', element: 'Yin Fire', color: 'red' },
  '戊': { pinyin: 'Wù', element: 'Yang Earth', color: 'yellow' },
  '己': { pinyin: 'Jǐ', element: 'Yin Earth', color: 'yellow' },
  '庚': { pinyin: 'Gēng', element: 'Yang Metal', color: 'gray' },
  '辛': { pinyin: 'Xīn', element: 'Yin Metal', color: 'gray' },
  '壬': { pinyin: 'Rén', element: 'Yang Water', color: 'blue' },
  '癸': { pinyin: 'Guǐ', element: 'Yin Water', color: 'blue' }
};

const BRANCH_INFO = {
  '子': { pinyin: 'Zǐ', animal: 'Rat', emoji: '🐀' },
  '丑': { pinyin: 'Chǒu', animal: 'Ox', emoji: '🐂' },
  '寅': { pinyin: 'Yín', animal: 'Tiger', emoji: '🐅' },
  '卯': { pinyin: 'Mǎo', animal: 'Rabbit', emoji: '🐇' },
  '辰': { pinyin: 'Chén', animal: 'Dragon', emoji: '🐉' },
  '巳': { pinyin: 'Sì', animal: 'Snake', emoji: '🐍' },
  '午': { pinyin: 'Wǔ', animal: 'Horse', emoji: '🐎' },
  '未': { pinyin: 'Wèi', animal: 'Goat', emoji: '🐐' },
  '申': { pinyin: 'Shēn', animal: 'Monkey', emoji: '🐒' },
  '酉': { pinyin: 'Yǒu', animal: 'Rooster', emoji: '🐓' },
  '戌': { pinyin: 'Xū', animal: 'Dog', emoji: '🐕' },
  '亥': { pinyin: 'Hài', animal: 'Pig', emoji: '🐖' }
};

// Calculate Ba Zi using sxtwl
function calculateBaZi(year, month, day, hour) {
  try {
    const ob = sxtwl.fromSolar(year, month, day);
    const jd = sxtwl.JD.JD(year, month, day + hour/24);
    const gz = sxtwl.getGZ(jd);
    
    // Calculate hour pillar
    const hourBranch = EARTHLY_BRANCHES[Math.floor((hour + 1) / 2) % 12];
    const dayStem = gz.dGz?.[0] || ob.dGz?.[0];
    const dayStemIndex = HEAVENLY_STEMS.indexOf(dayStem);
    const hourStemIndex = (dayStemIndex * 2 + Math.floor((hour + 1) / 2)) % 10;
    const hourStem = HEAVENLY_STEMS[hourStemIndex];
    
    return {
      pillars: {
        year: gz.yGz || ob.yGz,
        month: gz.mGz || ob.mGz,
        day: gz.dGz || ob.dGz,
        hour: hourStem + hourBranch
      },
      lunar: {
        year: ob.lYear,
        month: ob.lMonth,
        day: ob.lDay,
        monthStr: ob.lMonthStr,
        dayStr: ob.lDayStr
      },
      zodiac: BRANCH_INFO[ob.yGz?.[1] || gz.yGz?.[1]]?.animal || 'Unknown'
    };
  } catch (error) {
    console.error('Calculation error:', error);
    return { error: error.message };
  }
}

// Helper to get element colors for Tailwind
function getElementColor(stem) {
  if ('甲乙'.includes(stem)) return 'text-green-600 dark:text-green-400';
  if ('丙丁'.includes(stem)) return 'text-red-600 dark:text-red-400';
  if ('戊己'.includes(stem)) return 'text-yellow-600 dark:text-yellow-400';
  if ('庚辛'.includes(stem)) return 'text-gray-600 dark:text-gray-400';
  if ('壬癸'.includes(stem)) return 'text-blue-600 dark:text-blue-400';
  return 'text-slate-600 dark:text-slate-400';
}

// HTMX endpoint - returns HTML
app.get("/api/bazi/html", (req, res) => {
  const { year, month, day, hour = "0" } = req.query;
  
  if (!year || !month || !day) {
    return res.send('<div class="p-4 bg-red-100 dark:bg-red-900/50 rounded-xl text-red-700 dark:text-red-300">Please fill in all fields • 請填寫所有欄位</div>');
  }
  
  const y = parseInt(year);
  const m = parseInt(month);
  const d = parseInt(day);
  const h = parseInt(hour);
  
  const result = calculateBaZi(y, m, d, h);
  
  if (result.error) {
    return res.send(`<div class="p-4 bg-red-100 dark:bg-red-900/50 rounded-xl text-red-700 dark:text-red-300">Error: ${result.error}</div>`);
  }
  
  const renderPillar = (title, subtitle, chinese) => {
    if (!chinese || chinese.length !== 2) return '';
    const stem = chinese[0];
    const branch = chinese[1];
    const stemData = STEM_INFO[stem] || {};
    const branchData = BRANCH_INFO[branch] || {};
    const elementColor = getElementColor(stem);
    
    return `
      <div class="pillar-card rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-5 shadow-lg dark:shadow-2xl hover:shadow-xl dark:hover:shadow-purple-500/20">
        <div class="text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wide">
          ${title}
        </div>
        <div class="text-xs text-purple-600 dark:text-purple-400 mt-0.5">
          ${subtitle}
        </div>
        <div class="chinese-char chinese-glow font-bold mt-3 ${elementColor}">
          ${chinese}
        </div>
        <div class="text-lg font-semibold text-slate-700 dark:text-slate-200 mt-2">
          ${stemData.pinyin || ''}-${branchData.pinyin || ''}
        </div>
        <div class="text-sm text-slate-600 dark:text-slate-400 mt-1">
          ${stemData.element || ''} / ${branchData.animal || ''} ${branchData.emoji || ''}
        </div>
        <div class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-600">
          <div class="text-xs text-slate-500 dark:text-slate-400 space-y-1">
            <div class="flex justify-between">
              <span>Stem • 天干:</span>
              <span class="font-medium ${elementColor}">${stemData.element || ''}</span>
            </div>
            <div class="flex justify-between">
              <span>Branch • 地支:</span>
              <span class="font-medium text-slate-700 dark:text-slate-300">${branchData.animal || ''}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  };
  
  const html = `
    <div class="space-y-6">
      <div class="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 border border-purple-200 dark:border-purple-800 rounded-2xl">
        <p class="text-purple-900 dark:text-purple-100 font-bold text-lg">
          Your Ba Zi (Four Pillars of Destiny) • 您的八字
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm mt-2">
          Born: ${y}年${m}月${d}日 ${h}時
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm">
          Chinese Zodiac • 生肖: ${result.zodiac} ${BRANCH_INFO[result.pillars.year?.[1]]?.emoji || ''}
        </p>
        <p class="text-purple-700 dark:text-purple-300 text-sm">
          Lunar Date • 農曆: ${result.lunar.monthStr || ''}月${result.lunar.dayStr || ''}
        </p>
      </div>

      <div class="grid md:grid-cols-4 gap-4">
        ${renderPillar('Year Pillar • 年柱', 'Ancestry & Social • 祖先社交', result.pillars.year)}
        ${renderPillar('Month Pillar • 月柱', 'Career & Parents • 事業父母', result.pillars.month)}
        ${renderPillar('Day Pillar • 日柱', 'Self & Marriage • 自己婚姻', result.pillars.day)}
        ${renderPillar('Hour Pillar • 時柱', 'Children & Future • 子女未來', result.pillars.hour)}
      </div>

      <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 shadow-lg dark:shadow-2xl">
        <h3 class="font-bold text-sm mb-4 text-slate-900 dark:text-slate-100">
          Element Analysis • 五行分析
        </h3>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          ${['year', 'month', 'day', 'hour'].map(key => {
            const pillar = result.pillars[key];
            if (!pillar) return '';
            const stem = pillar[0];
            const stemData = STEM_INFO[stem] || {};
            const element = stemData.element?.split(' ')[1] || '';
            const elementColor = getElementColor(stem);
            
            return `
              <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-700/50">
                <div class="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold">${key}</div>
                <div class="font-bold mt-1 ${elementColor}">${element}</div>
                <div class="text-xs text-slate-600 dark:text-slate-400">${stemData.element?.split(' ')[0] || ''}</div>
                <div class="text-xs text-slate-500 dark:text-slate-500 mt-1">${stem} ${stemData.pinyin || ''}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>
  `;
  
  res.send(html);
});

// Test endpoint for HTMX
app.get("/api/test/html", (req, res) => {
  const tests = [
    { year: 1967, month: 10, day: 7, name: "Oct 7, 1967 (before Cold Dew)" },
    { year: 1967, month: 10, day: 8, name: "Oct 8, 1967 (Cold Dew day)" },
    { year: 1967, month: 10, day: 9, name: "Oct 9, 1967 (SHOULD BE DOG MONTH)" },
    { year: 1967, month: 10, day: 10, name: "Oct 10, 1967 (after Cold Dew)" }
  ];
  
  let html = '<div class="bg-slate-800 rounded-xl p-6 space-y-3">';
  html += '<h3 class="font-bold text-lg mb-4">Test Results • 測試結果</h3>';
  
  for (const test of tests) {
    const result = calculateBaZi(test.year, test.month, test.day, 0);
    const isOct9 = test.name.includes('SHOULD BE');
    const bgClass = isOct9 ? 'bg-red-900/50 border-red-500' : 'bg-slate-700';
    
    html += `
      <div class="p-3 ${bgClass} border rounded">
        <div class="font-semibold text-sm">${test.name}</div>
        <div class="mt-1 text-xs grid grid-cols-4 gap-2">
          <span>Year: ${result.pillars?.year || 'ERROR'}</span>
          <span class="${isOct9 ? 'text-yellow-300 font-bold' : ''}">
            Month: ${result.pillars?.month || 'ERROR'}
          </span>
          <span>Day: ${result.pillars?.day || 'ERROR'}</span>
          <span>Zodiac: ${result.zodiac || 'ERROR'}</span>
        </div>
      </div>
    `;
  }
  
  html += '</div>';
  res.send(html);
});

// JSON API endpoints (for non-HTMX requests)
app.get("/api/bazi", (req, res) => {
  const { year, month, day, hour = "0" } = req.query;
  
  if (!year || !month || !day) {
    return res.status(400).json({ error: "Missing required parameters" });
  }
  
  const y = parseInt(year);
  const m = parseInt(month);
  const d = parseInt(day);
  const h = parseInt(hour);
  
  const result = calculateBaZi(y, m, d, h);
  res.json(result);
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`🚀 Accurate Ba Zi server with sxtwl-js running!`);
  console.log(`📍 http://localhost:${PORT}`);
  console.log(`✅ Using sxtwl-js for accurate astronomical calculations`);
  console.log(`🎨 Features: Dark mode, HTMX, bilingual support, beautiful UI`);
});
