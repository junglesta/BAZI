# Accurate Ba Zi Calculator 🎯

A beautiful, accurate Ba Zi (Four Pillars of Destiny) calculator with:
- ✅ **Accurate calculations** using sxtwl-js (壽星天文曆)
- 🌙 **Dark mode** support
- 🌐 **Bilingual** (English/Chinese)
- ⚡ **HTMX** for smooth interactions
- 🎨 **Beautiful UI** with Tailwind CSS

## Quick Start

```bash
# Install dependencies
pnpm install

# Run the server
pnpm start

# Open http://localhost:8080
```

## Why sxtwl-js?

The sxtwl library (壽星天文曆) provides astronomically accurate calculations for:
- Solar terms (節氣) which determine month pillars
- Proper handling of time zones
- Correct leap month calculations
- Astronomical precision for day/month boundaries

## Features

- 📅 Calculate Ba Zi for any date from 1900-2100
- 🌏 Multiple timezone support
- 🧪 Built-in test suite for accuracy verification
- 💾 Caching for performance
- 📱 Responsive design
- 🌙 Auto/manual dark mode

## Testing

```bash
# Run accuracy tests
pnpm test

# Test specific date (Oct 9, 1967)
curl "http://localhost:8080/api/bazi?year=1967&month=10&day=9&hour=1"
```

## API Endpoints

- `GET /` - Main UI
- `GET /api/bazi?year=YYYY&month=MM&day=DD&hour=HH` - JSON API
- `GET /api/bazi/html?year=YYYY&month=MM&day=DD&hour=HH` - HTMX HTML response
- `GET /api/test/html` - Run test suite

## Known Accurate Results

- Oct 9, 1967: Month pillar should be 庚戌 (Metal Dog) ✅
- This is correct because Cold Dew (寒露) occurs around Oct 8-9

## License

MIT
