// Test accuracy of Ba Zi calculations
import sxtwl from 'sxtwl';

console.log('🧪 Testing Ba Zi accuracy with sxtwl-js...\n');

const testCases = [
  { date: [1967, 10, 9, 1], expected_month: '庚戌', name: 'Oct 9, 1967 - Critical test' },
  { date: [2000, 1, 1, 0], name: 'Millennium' },
  { date: [2025, 2, 4, 0], name: 'Spring Begins 2025' }
];

const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

for (const test of testCases) {
  const [y, m, d, h] = test.date;
  
  const ob = sxtwl.fromSolar(y, m, d);
  const jd = sxtwl.JD.JD(y, m, d + h/24);
  const gz = sxtwl.getGZ(jd);
  
  console.log(`${test.name}:`);
  console.log(`  Date: ${y}-${m}-${d} ${h}:00`);
  console.log(`  Year:  ${gz.yGz || ob.yGz}`);
  console.log(`  Month: ${gz.mGz || ob.mGz} ${test.expected_month ? 
    (gz.mGz === test.expected_month ? '✅ CORRECT!' : '❌ WRONG!') : ''}`);
  console.log(`  Day:   ${gz.dGz || ob.dGz}`);
  console.log('');
}

console.log('✅ Test complete!');
