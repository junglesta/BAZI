// Compare different lunar calendar libraries for accuracy
import { Solar } from 'lunar-javascript';
import CalendarChinese from 'date-chinese';
import chineseLunar from 'chinese-lunar';
import LunarCalendar from 'lunar-calendar';

console.log('🔬 Comparing Lunar Calendar Libraries for Ba Zi Accuracy\n');
console.log('=' .repeat(70));

const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// Test case: Oct 9, 1967 - The problematic date
const testDate = { year: 1967, month: 10, day: 9, hour: 1 };

console.log(`\nTest Date: ${testDate.year}-${testDate.month}-${testDate.day} ${testDate.hour}:00`);
console.log('Expected Month Pillar: 庚戌 (Metal Dog) - After Cold Dew\n');

// Method 1: lunar-javascript
console.log('1. lunar-javascript (6tail):');
try {
    const solar = Solar.fromYmdHms(testDate.year, testDate.month, testDate.day, testDate.hour, 0, 0);
    const lunar = solar.getLunar();
    const ec = lunar.getEightChar();
    
    console.log(`   Year:  ${ec.getYear()}`);
    console.log(`   Month: ${ec.getMonth()} ${ec.getMonth() === '庚戌' ? '✅' : '❌'}`);
    console.log(`   Day:   ${ec.getDay()}`);
    console.log(`   Hour:  ${ec.getTime()}`);
    
    // Check if we can get solar terms
    const jieQi = lunar.getJieQi();
    console.log(`   Solar Term: ${jieQi || 'N/A'}`);
} catch (e) {
    console.log(`   Error: ${e.message}`);
}

// Method 2: date-chinese
console.log('\n2. date-chinese:');
try {
    const cal = new CalendarChinese();
    cal.fromGregorian(testDate.year, testDate.month, testDate.day);
    
    // This library needs manual Ba Zi calculation
    const cycle = cal.cycle;
    const year = cal.year;
    const month = cal.month;
    const day = cal.day;
    
    console.log(`   Chinese Date: Cycle ${cycle}, Year ${year}, Month ${month}, Day ${day}`);
    console.log(`   (Requires manual Ba Zi calculation)`);
} catch (e) {
    console.log(`   Error: ${e.message}`);
}

// Method 3: chinese-lunar
console.log('\n3. chinese-lunar:');
try {
    const date = new Date(testDate.year, testDate.month - 1, testDate.day, testDate.hour);
    const result = chineseLunar.solarToLunar(date);
    
    console.log(`   Result: ${JSON.stringify(result)}`);
    console.log(`   (May not have full Ba Zi support)`);
} catch (e) {
    console.log(`   Error: ${e.message}`);
}

// Method 4: lunar-calendar
console.log('\n4. lunar-calendar:');
try {
    const result = LunarCalendar.solarToLunar(testDate.year, testDate.month, testDate.day);
    
    console.log(`   GanZhi Year: ${result.GanZhiYear || 'N/A'}`);
    console.log(`   GanZhi Month: ${result.GanZhiMonth || 'N/A'}`);
    console.log(`   GanZhi Day: ${result.GanZhiDay || 'N/A'}`);
} catch (e) {
    console.log(`   Error: ${e.message}`);
}

console.log('\n' + '=' .repeat(70));
console.log('📊 Recommendation: Use the library that gives correct results');
console.log('   for the Oct 9, 1967 test case (should be 庚戌 month)');
